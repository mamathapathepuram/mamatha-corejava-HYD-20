 package com.example.demo.controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Placement;
import com.example.demo.service.PlacementService;


@RestController
public class PlacementController {
	@Autowired
	 PlacementService ps ;
	
	
	@PostMapping("/placements")
	public Placement savePlacement(@RequestBody Placement placement) {
		return ps.savePlacement(placement);
		
	}
	
	 @GetMapping("/placements")
	    public List<Placement> fetchPlacementList() {
	        //LOGGER.info("Inside fetchDepartmentList of DepartmentController");
	        return ps.fetchPlacementList();
	    }

	@GetMapping("/placements/{id}")
    public Placement fetchtById(@PathVariable("id") Long id)
            {
        return ps.fetchPlacementById(id);
    }
    
    @DeleteMapping("/placements/{id}")
    public String deletePlacementById(@PathVariable("id") Long id) 
    {
    	ps.deletePlacementById(id);
        return "Department deleted Successfully!!";
    }
    
    @PutMapping("/placements/{id}")
    public Placement updatePlacement(@PathVariable("id") Long id, @RequestBody Placement placement) {
        return ps.updatePlacement(id,placement);
    }
	}



